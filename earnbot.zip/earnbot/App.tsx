import 'react-native-url-polyfill/auto';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator, Alert, FlatList, KeyboardAvoidingView, Linking, Platform,
  RefreshControl, SafeAreaView, ScrollView, StyleSheet, Text, TextInput,
  TouchableOpacity, View,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';
import type { Session } from '@supabase/supabase-js';

const SB_URL = process.env.EXPO_PUBLIC_SUPABASE_URL ?? '';
const KEY = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ?? '';
const supabase = createClient(SB_URL, KEY, {
  auth: { storage: AsyncStorage, autoRefreshToken: true, persistSession: true, detectSessionInUrl: false },
});

const C = { bg: '#0b0f14', card: '#141b24', line: '#223041', text: '#e8eef5', dim: '#8aa0b6', green: '#3ddc97', red: '#ff6b6b', blue: '#4da3ff' };
const LAST_ORDER = 'earnbot_last_order';
const kes = (n: number) => 'KES ' + Math.round(n).toLocaleString();

type Tab = 'home' | 'chat' | 'queue' | 'orders';

export default function App() {
  const [session, setSession] = useState<Session | null>(null);
  const [ready, setReady] = useState(false);
  const [tab, setTab] = useState<Tab>('home');
  const [ownerLogin, setOwnerLogin] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setReady(true); });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => { setSession(s); if (s) setOwnerLogin(false); });
    return () => sub.subscription.unsubscribe();
  }, []);

  if (!ready) return <View style={[s.fill, s.center]}><ActivityIndicator color={C.blue} /></View>;
  if (!SB_URL || !KEY) return <Centered text="Missing EXPO_PUBLIC_SUPABASE_URL / EXPO_PUBLIC_SUPABASE_ANON_KEY. Add them as GitHub secrets and rebuild." />;
  if (!session) {
    return ownerLogin
      ? <Login onBack={() => setOwnerLogin(false)} />
      : <Shop onOwner={() => setOwnerLogin(true)} />;
  }

  return (
    <SafeAreaView style={s.fill}>
      <StatusBar style="light" />
      <View style={s.fill}>
        {tab === 'home' && <Home />}
        {tab === 'chat' && <Chat session={session} />}
        {tab === 'queue' && <Queue />}
        {tab === 'orders' && <Orders />}
      </View>
      <View style={s.tabs}>
        {(['home', 'chat', 'queue', 'orders'] as Tab[]).map((t) => (
          <TouchableOpacity key={t} style={s.tab} onPress={() => setTab(t)}>
            <Text style={[s.tabText, tab === t && { color: C.green }]}>{t.toUpperCase()}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </SafeAreaView>
  );
}

function Centered({ text }: { text: string }) {
  return <View style={[s.fill, s.center, { padding: 24 }]}><Text style={{ color: C.text, textAlign: 'center' }}>{text}</Text></View>;
}

type Service = { id: string; name: string; description: string; price_kes: number };

function Shop({ onOwner }: { onOwner: () => void }) {
  const [services, setServices] = useState<Service[]>([]);
  const [sel, setSel] = useState<string>('');
  const [phone, setPhone] = useState('');
  const [input, setInput] = useState('');
  const [status, setStatus] = useState('');
  const [isErr, setIsErr] = useState(false);
  const [result, setResult] = useState('');
  const [busy, setBusy] = useState(false);

  const say = (m: string, err = false) => { setStatus(m); setIsErr(err); };

  const loadServices = useCallback(async () => {
    try {
      const r = await fetch(`${SB_URL}/functions/v1/orders`, { headers: { apikey: KEY } });
      const d = await r.json();
      setServices(d.services ?? []);
      if (d.services?.length) setSel((cur) => cur || d.services[0].id);
    } catch {
      say('Could not load services. Check your connection and try again.', true);
    }
  }, []);
  useEffect(() => { loadServices(); }, [loadServices]);

  const alive = useRef(true);
  useEffect(() => () => { alive.current = false; }, []);
  const forget = () => { AsyncStorage.removeItem(LAST_ORDER).catch(() => {}); };

  const poll = async (id: string, n: number): Promise<void> => {
    if (!alive.current) return;
    if (n > 60) { say('Still waiting. If you paid, reopen the app in a few minutes. Your result will appear here.', true); setBusy(false); return; }
    try {
      const r = await fetch(`${SB_URL}/functions/v1/orders?id=${encodeURIComponent(id)}`, { headers: { apikey: KEY } });
      const d = await r.json();
      if (d.error) { forget(); say(''); setBusy(false); return; }
      if (d.status === 'delivered') { say('Done. Here is your result:'); setResult(d.result ?? ''); setBusy(false); return; }
      if (d.status === 'failed') { forget(); say('Payment did not go through. You were not charged. Try again.', true); setBusy(false); return; }
      if (d.problem) { say(d.problem, true); setBusy(false); return; }
      if (d.status === 'paid') say('Payment received. Writing your result...');
    } catch { /* keep polling */ }
    setTimeout(() => poll(id, n + 1), 4000);
  };

  // If the app was closed while the customer was in M-Pesa, pick the order back up.
  useEffect(() => {
    AsyncStorage.getItem(LAST_ORDER).then((id) => {
      if (id && alive.current) { setBusy(true); say('Checking your last order...'); poll(id, 0); }
    }).catch(() => {});
  }, []);

  const newOrder = () => { forget(); setResult(''); say(''); setInput(''); };

  const pay = async () => {
    if (busy) return;
    if (!/^(0|254)[17]\d{8}$/.test(phone.replace(/\D/g, ''))) return say('Enter a valid Safaricom number, e.g. 07XXXXXXXX', true);
    if (input.trim().length < 20) return say('Add a bit more detail (at least 20 characters).', true);
    setBusy(true); setResult(''); say('Starting payment...');
    try {
      const r = await fetch(`${SB_URL}/functions/v1/orders`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', apikey: KEY },
        body: JSON.stringify({ service_id: sel, phone, input }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || 'Something went wrong');
      AsyncStorage.setItem(LAST_ORDER, d.id).catch(() => {});
      say(`${d.message} Waiting for payment...`);
      poll(d.id, 0);
    } catch (e: any) { say(e.message, true); setBusy(false); }
  };

  const cur = services.find((x) => x.id === sel);
  return (
    <SafeAreaView style={s.fill}>
      <StatusBar style="light" />
      <ScrollView contentContainerStyle={{ padding: 16 }} keyboardShouldPersistTaps="handled">
        <Text style={s.h1}>Quick AI Services</Text>
        <Text style={[s.dim, { marginBottom: 14 }]}>Pick a service, pay with M-Pesa, get your result here in about a minute.</Text>

        {services.map((sv) => (
          <TouchableOpacity key={sv.id} onPress={() => setSel(sv.id)} style={[s.card, sel === sv.id && { borderColor: C.green }]}>
            <Text style={{ color: C.text, fontWeight: '700' }}>{sv.name} · {kes(sv.price_kes)}</Text>
            <Text style={s.dim}>{sv.description}</Text>
          </TouchableOpacity>
        ))}
        {!services.length && <Text style={s.dim}>Loading services...</Text>}

        <Text style={[s.dim, { marginTop: 8, marginBottom: 6 }]}>M-Pesa number</Text>
        <TextInput style={s.input} placeholder="07XXXXXXXX" placeholderTextColor={C.dim} keyboardType="phone-pad" value={phone} onChangeText={setPhone} />
        <Text style={[s.dim, { marginBottom: 6 }]}>Your details</Text>
        <TextInput
          style={[s.input, { minHeight: 140, textAlignVertical: 'top' }]}
          placeholder="Paste your CV and the job you want, or describe your business idea..."
          placeholderTextColor={C.dim} multiline value={input} onChangeText={setInput}
        />
        <TouchableOpacity style={[s.btn, busy && { opacity: 0.5 }]} onPress={pay} disabled={busy || !cur}>
          <Text style={s.btnText}>{cur ? `Pay ${kes(cur.price_kes)} and get my result` : 'Pay and get my result'}</Text>
        </TouchableOpacity>

        {!!status && <Text style={{ color: isErr ? C.red : C.dim, marginTop: 14 }}>{status}</Text>}
        {busy && <ActivityIndicator color={C.blue} style={{ marginTop: 10 }} />}
        {!!result && (
          <>
            <View style={[s.card, { marginTop: 12 }]}><Text selectable style={{ color: C.text }}>{result}</Text></View>
            <TouchableOpacity style={[s.btn, { backgroundColor: C.line }]} onPress={newOrder}><Text style={[s.btnText, { color: C.text }]}>Start a new order</Text></TouchableOpacity>
          </>
        )}

        <Text style={[s.dim, { fontSize: 12, marginTop: 20 }]}>
          Results are AI-generated. Review them before you use them. You'll get an M-Pesa prompt on your phone; enter your PIN to pay. If something goes wrong after you pay, contact the owner for a fix or refund.
        </Text>
        <TouchableOpacity onPress={onOwner} style={{ marginTop: 24, alignItems: 'center' }}>
          <Text style={{ color: C.dim, fontSize: 12, textDecorationLine: 'underline' }}>Owner sign in</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

function Login({ onBack }: { onBack: () => void }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const go = async () => {
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    setBusy(false);
    if (error) Alert.alert('Sign in failed', error.message);
  };
  return (
    <SafeAreaView style={[s.fill, s.center, { padding: 24 }]}>
      <StatusBar style="light" />
      <Text style={s.h1}>Earnbot</Text>
      <Text style={[s.dim, { marginBottom: 20 }]}>Owner sign in</Text>
      <TextInput style={s.input} placeholder="Email" placeholderTextColor={C.dim} autoCapitalize="none" keyboardType="email-address" value={email} onChangeText={setEmail} />
      <TextInput style={s.input} placeholder="Password" placeholderTextColor={C.dim} secureTextEntry value={password} onChangeText={setPassword} />
      <TouchableOpacity style={s.btn} onPress={go} disabled={busy}>
        <Text style={s.btnText}>{busy ? '...' : 'Sign in'}</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={onBack} style={{ marginTop: 18 }}>
        <Text style={{ color: C.dim, textDecorationLine: 'underline' }}>Back to services</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

function Home() {
  const [data, setData] = useState({ earn: 0, cost: 0 });
  const [refreshing, setRefreshing] = useState(false);
  const load = useCallback(async () => {
    setRefreshing(true);
    const start = new Date(); start.setUTCDate(1); start.setUTCHours(0, 0, 0, 0);
    const { data: rows } = await supabase.from('ledger').select('kind, amount_kes').gte('created_at', start.toISOString());
    let earn = 0, cost = 0;
    (rows ?? []).forEach((r: any) => (r.kind === 'earning' ? (earn += Number(r.amount_kes)) : (cost += Number(r.amount_kes))));
    setData({ earn, cost });
    setRefreshing(false);
  }, []);
  useEffect(() => { load(); }, [load]);
  const net = data.earn - data.cost;
  return (
    <ScrollView contentContainerStyle={{ padding: 16 }} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={load} tintColor={C.blue} />}>
      <Text style={s.h1}>This month</Text>
      <View style={s.card}><Text style={s.dim}>Earned (M-Pesa)</Text><Text style={[s.big, { color: C.green }]}>{kes(data.earn)}</Text></View>
      <View style={s.card}><Text style={s.dim}>Agent API cost</Text><Text style={[s.big, { color: C.red }]}>{kes(data.cost)}</Text></View>
      <View style={s.card}>
        <Text style={s.dim}>Net</Text>
        <Text style={[s.big, { color: net >= 0 ? C.green : C.red }]}>{kes(net)}</Text>
        <Text style={s.dim}>{net >= 0 ? 'The agent is paying for itself.' : 'Not paying for itself yet. Check the Chat tab for what to try next.'}</Text>
      </View>
      <Text style={[s.dim, { marginTop: 8 }]}>Pull down to refresh. Costs are estimates from token usage.</Text>
    </ScrollView>
  );
}

type Msg = { role: 'user' | 'assistant'; content: string };

function Chat({ session }: { session: Session }) {
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const send = async () => {
    const t = text.trim();
    if (!t || busy) return;
    const next: Msg[] = [...msgs, { role: 'user', content: t }];
    setMsgs(next); setText(''); setBusy(true);
    try {
      const res = await fetch(`${SB_URL}/functions/v1/agent`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session.access_token}`, apikey: KEY },
        body: JSON.stringify({ messages: next }),
      });
      const j = await res.json();
      setMsgs([...next, { role: 'assistant', content: j.reply ?? `Error: ${j.error ?? res.status}` }]);
    } catch (e: any) {
      setMsgs([...next, { role: 'assistant', content: 'Network error: ' + e.message }]);
    }
    setBusy(false);
  };
  return (
    <KeyboardAvoidingView style={s.fill} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <FlatList
        data={msgs}
        keyExtractor={(_, i) => String(i)}
        contentContainerStyle={{ padding: 16 }}
        ListEmptyComponent={<Text style={s.dim}>Try: "How are we doing this month?" or "Add Mama Njeri's eatery in Nakuru as a lead and draft a pitch."</Text>}
        renderItem={({ item }) => (
          <View style={[s.bubble, item.role === 'user' ? s.me : s.bot]}><Text style={{ color: C.text }}>{item.content}</Text></View>
        )}
      />
      {busy && <ActivityIndicator color={C.blue} style={{ marginBottom: 6 }} />}
      <View style={s.composer}>
        <TextInput style={[s.input, { flex: 1, marginBottom: 0 }]} placeholder="Message Earnbot" placeholderTextColor={C.dim} value={text} onChangeText={setText} multiline />
        <TouchableOpacity style={[s.btn, { marginLeft: 8, paddingHorizontal: 16 }]} onPress={send}><Text style={s.btnText}>Send</Text></TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

function Queue() {
  const [items, setItems] = useState<any[]>([]);
  const load = useCallback(async () => {
    const { data } = await supabase.from('actions').select('*').eq('status', 'pending').order('created_at', { ascending: false });
    setItems(data ?? []);
  }, []);
  useEffect(() => { load(); }, [load]);

  const decide = async (a: any, ok: boolean) => {
    if (ok && a.type === 'new_service') {
      const p = a.payload;
      const { error } = await supabase.from('services').upsert({ id: p.id, name: p.name, description: p.description, price_kes: p.price_kes, system_prompt: p.system_prompt });
      if (error) return Alert.alert('Could not add service', error.message);
    }
    if (ok && a.type === 'outreach') await supabase.from('leads').update({ status: 'sent' }).eq('id', a.payload.lead_id);
    await supabase.from('actions').update({ status: ok ? 'approved' : 'rejected', decided_at: new Date().toISOString() }).eq('id', a.id);
    load();
  };
  const openWhatsApp = (a: any) => {
    const raw = String(a.payload.contact ?? '').replace(/\D/g, '');
    if (!raw) return Alert.alert('No contact saved for this lead');
    const num = raw.startsWith('0') ? '254' + raw.slice(1) : raw;
    Linking.openURL(`https://wa.me/${num}?text=${encodeURIComponent(a.payload.message)}`);
  };

  return (
    <FlatList
      data={items}
      keyExtractor={(i) => i.id}
      contentContainerStyle={{ padding: 16 }}
      refreshControl={<RefreshControl refreshing={false} onRefresh={load} tintColor={C.blue} />}
      ListHeaderComponent={<Text style={s.h1}>Approval queue</Text>}
      ListEmptyComponent={<Text style={s.dim}>Nothing waiting. The agent can only propose, you decide.</Text>}
      renderItem={({ item }) => (
        <View style={s.card}>
          {item.type === 'outreach' ? (
            <>
              <Text style={s.dim}>WhatsApp to {item.payload.lead_name}</Text>
              <Text style={{ color: C.text, marginVertical: 8 }}>{item.payload.message}</Text>
              <TouchableOpacity style={[s.btn, { backgroundColor: C.blue }]} onPress={() => openWhatsApp(item)}><Text style={s.btnText}>Open in WhatsApp</Text></TouchableOpacity>
            </>
          ) : (
            <>
              <Text style={s.dim}>New service proposal</Text>
              <Text style={{ color: C.text, fontWeight: '700', marginTop: 6 }}>{item.payload.name} · {kes(item.payload.price_kes)}</Text>
              <Text style={{ color: C.text, marginVertical: 6 }}>{item.payload.description}</Text>
              <Text style={s.dim}>Instructions the agent will follow for each order:</Text>
              <Text style={{ color: C.text, marginVertical: 4 }}>{String(item.payload.system_prompt ?? '').slice(0, 600)}</Text>
            </>
          )}
          <View style={{ flexDirection: 'row', marginTop: 10 }}>
            <TouchableOpacity style={[s.btn, { flex: 1, marginRight: 6 }]} onPress={() => decide(item, true)}><Text style={s.btnText}>{item.type === 'outreach' ? 'Mark sent' : 'Approve'}</Text></TouchableOpacity>
            <TouchableOpacity style={[s.btn, { flex: 1, backgroundColor: C.line }]} onPress={() => decide(item, false)}><Text style={[s.btnText, { color: C.text }]}>Reject</Text></TouchableOpacity>
          </View>
        </View>
      )}
    />
  );
}

function Orders() {
  const [items, setItems] = useState<any[]>([]);
  const load = useCallback(async () => {
    const { data } = await supabase.from('orders').select('id, created_at, service_id, amount_kes, status, mpesa_receipt, error').order('created_at', { ascending: false }).limit(50);
    setItems(data ?? []);
  }, []);
  useEffect(() => { load(); }, [load]);
  return (
    <FlatList
      data={items}
      keyExtractor={(i) => i.id}
      contentContainerStyle={{ padding: 16 }}
      refreshControl={<RefreshControl refreshing={false} onRefresh={load} tintColor={C.blue} />}
      ListHeaderComponent={<Text style={s.h1}>Orders</Text>}
      ListEmptyComponent={<Text style={s.dim}>No orders yet. Share the app with customers.</Text>}
      renderItem={({ item }) => (
        <View style={s.card}>
          <Text style={{ color: C.text, fontWeight: '700' }}>{item.service_id} · {kes(item.amount_kes)}</Text>
          <Text style={{ color: item.status === 'delivered' ? C.green : item.status === 'failed' ? C.red : C.dim }}>{item.status}{item.mpesa_receipt ? ` · ${item.mpesa_receipt}` : ''}</Text>
          {item.error ? <Text style={{ color: C.red, marginTop: 4 }}>{item.error}</Text> : null}
          <Text style={s.dim}>{new Date(item.created_at).toLocaleString()}</Text>
        </View>
      )}
    />
  );
}

const s = StyleSheet.create({
  fill: { flex: 1, backgroundColor: C.bg },
  center: { alignItems: 'center', justifyContent: 'center' },
  h1: { color: C.text, fontSize: 24, fontWeight: '800', marginBottom: 12 },
  dim: { color: C.dim },
  big: { fontSize: 28, fontWeight: '800', marginVertical: 4 },
  card: { backgroundColor: C.card, borderColor: C.line, borderWidth: 1, borderRadius: 12, padding: 14, marginBottom: 12 },
  input: { backgroundColor: C.card, borderColor: C.line, borderWidth: 1, borderRadius: 10, color: C.text, padding: 12, marginBottom: 10, width: '100%' },
  btn: { backgroundColor: C.green, borderRadius: 10, paddingVertical: 12, alignItems: 'center', width: undefined },
  btnText: { color: '#04120b', fontWeight: '800' },
  tabs: { flexDirection: 'row', borderTopColor: C.line, borderTopWidth: 1, backgroundColor: C.card },
  tab: { flex: 1, paddingVertical: 14, alignItems: 'center' },
  tabText: { color: C.dim, fontWeight: '700', fontSize: 12, letterSpacing: 1 },
  bubble: { padding: 12, borderRadius: 12, marginBottom: 8, maxWidth: '88%' },
  me: { backgroundColor: '#1f3b57', alignSelf: 'flex-end' },
  bot: { backgroundColor: C.card, alignSelf: 'flex-start', borderColor: C.line, borderWidth: 1 },
  composer: { flexDirection: 'row', padding: 10, borderTopColor: C.line, borderTopWidth: 1, alignItems: 'flex-end' },
});
