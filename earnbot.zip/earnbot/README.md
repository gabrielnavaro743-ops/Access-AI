# Earnbot

A supervised money-making agent as an installable Android app.

- **Sells** AI services (CV rewrite, one-page business plan) inside the app. Customers open the app, pick a service, pay by M-Pesa STK push, and the result appears in the app.
- **Hunts local leads** (hotels, eateries, butcheries) and drafts WhatsApp pitches for you.
- **Tracks its own books.** Every M-Pesa payment is an earning, every Claude API call is a cost, so you see whether it pays for itself.
- **Can't go rogue.** The agent only proposes. Messages and new services wait in an approval queue, and a monthly API cost cap stops runaway spend.

## How it fits together

```
Android app, owner side (Expo)  ──►  Edge Function "agent"  ──►  Claude API (tool use)
                                          │
Android app, customer side ──► "orders" function ──► M-Pesa Daraja STK push
                              ▲                        │
                              └── "mpesa-callback" ◄───┘  (records earning, generates deliverable)
```

The Claude API key lives only in Supabase secrets, never in the app.

## Setup (phone-friendly, everything runs on GitHub)

1. **Supabase**: create a free project. Note the Project URL, anon key, project ref and DB password. Create an access token at supabase.com/dashboard/account/tokens.
2. **Owner account**: in Supabase, Authentication > Users > add a user with your email and a password, then go to Authentication > Sign In / Providers and **turn off "Allow new users to sign up"** (customers never need an account). After the first backend deploy, run this in the SQL editor:
   `update settings set owner_email = 'you@example.com' where id = 1;`
   Only this email can use the agent or read your data.
3. **GitHub repo**: push this folder. Under Settings > Secrets and variables > Actions add:

| Secret | What |
|---|---|
| `SUPABASE_URL` | Project URL |
| `SUPABASE_ANON_KEY` | anon/publishable key |
| `SUPABASE_PROJECT_REF` | the ref in your URL |
| `SUPABASE_ACCESS_TOKEN` | personal access token |
| `SUPABASE_DB_PASSWORD` | database password |
| `ANTHROPIC_API_KEY` | from console.anthropic.com |
| `CALLBACK_SECRET` | any long random string |
| `MPESA_CONSUMER_KEY`, `MPESA_CONSUMER_SECRET`, `MPESA_SHORTCODE`, `MPESA_PASSKEY` | from developer.safaricom.co.ke |
| `MPESA_ENV` | `sandbox` (default) or `production` |
| `MPESA_TXN_TYPE`, `MPESA_PARTYB` | only for a **Till**: `CustomerBuyGoodsOnline` and your till number. Leave empty for a Paybill. |
| `BUSINESS_CONTEXT` | optional, one sentence about your business |
| `USD_KES`, `PRICE_IN_PER_MTOK`, `PRICE_OUT_PER_MTOK`, `CLAUDE_MODEL` | optional: exchange rate, token prices and model used for the books and replies |

4. **Run the workflows** (Actions tab): `Deploy backend`, then `Build APK`.
5. **Install**: open the finished `Build APK` run, download the `earnbot-apk` artifact, unzip, install the APK. Share the same APK with customers. They see the order screen; you tap "Owner sign in" at the bottom.

## Go live checklist

- Test everything on **sandbox** first with Daraja test credentials.
- Going to production needs a Safaricom Paybill/Till and Daraja Go-Live approval. Register your callback URL there.
- Set the cost cap: `update settings set monthly_cost_cap_usd = 10 where id = 1;`
- Token prices in `_shared/shared.ts` default to estimates. Override with secrets `PRICE_IN_PER_MTOK`, `PRICE_OUT_PER_MTOK` and `USD_KES` for accurate books.
- Customers paying for AI output: keep the "review before use" notice, handle refunds quickly if delivery fails (the Orders tab shows these), and check Kenyan data-protection rules before storing customer CVs.
- Outreach goes through WhatsApp **you** tap send on. Don't automate bulk messaging, it gets numbers banned and can breach platform rules.

## What was tested

The backend logic (agent loop, ordering, M-Pesa callbacks, delivery) was run against a real Postgres with your schema and row-level security, using fake Claude and Daraja servers: 40 checks, including auth, duplicate and simultaneous callbacks, retries, the cost cap and abuse limits. The Android build itself runs for the first time on GitHub, so send any red workflow log back and it gets fixed.

## Honest expectations

This won't print money by itself. Income depends on getting customers to install the app: share the APK in local groups, use it at your butchery counter, run lead outreach. The ledger tells you quickly whether a service earns more than it costs, and you can ask the agent to propose new services or drop weak ones.

## Next upgrades

Retry-delivery button, web search for real lead discovery, refunds via Daraja reversal, agent-written marketing posts in the approval queue.
