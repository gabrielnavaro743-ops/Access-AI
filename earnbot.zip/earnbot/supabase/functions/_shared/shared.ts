import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

export const MODEL = Deno.env.get("CLAUDE_MODEL") ?? "claude-sonnet-5-5";
const USD_KES = Number(Deno.env.get("USD_KES") ?? "130");
// Token prices in USD per million tokens. Check current pricing and override via secrets.
const PRICE_IN = Number(Deno.env.get("PRICE_IN_PER_MTOK") ?? "3");
const PRICE_OUT = Number(Deno.env.get("PRICE_OUT_PER_MTOK") ?? "15");

export const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};

export const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...cors, "Content-Type": "application/json" },
  });

export const admin = () =>
  createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

// deno-lint-ignore no-explicit-any
type DB = any;

export function monthStartIso() {
  const d = new Date();
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1)).toISOString();
}

export async function monthTotals(db: DB) {
  const { data } = await db
    .from("ledger")
    .select("kind, amount_kes")
    .gte("created_at", monthStartIso());
  let earnings = 0;
  let costs = 0;
  for (const r of data ?? []) {
    if (r.kind === "earning") earnings += Number(r.amount_kes);
    else costs += Number(r.amount_kes);
  }
  return { earnings, costs, net: earnings - costs };
}

/** Calls Claude and logs the real token cost to the ledger. Refuses once the monthly cap is hit.
 * enforceCap=false is used for work a customer has already paid for: never refuse paid delivery. */
export async function claude(
  db: DB,
  body: Record<string, unknown>,
  note: string,
  enforceCap = true,
) {
  if (enforceCap) {
    const { data: s } = await db.from("settings").select("monthly_cost_cap_usd").eq("id", 1).single();
    const capKes = Number(s?.monthly_cost_cap_usd ?? 10) * USD_KES;
    const { costs } = await monthTotals(db);
    if (costs >= capKes) throw new Error("Monthly API cost cap reached. Raise it in settings or wait for next month.");
  }

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "x-api-key": Deno.env.get("ANTHROPIC_API_KEY")!,
      "anthropic-version": "2023-06-01",
      "content-type": "application/json",
    },
    body: JSON.stringify(body),
  });
  const j = await res.json();
  if (!res.ok) throw new Error(j?.error?.message ?? `Claude API error ${res.status}`);

  const kes =
    (((j.usage?.input_tokens ?? 0) * PRICE_IN + (j.usage?.output_tokens ?? 0) * PRICE_OUT) / 1e6) *
    USD_KES;
  await db.from("ledger").insert({ kind: "cost", amount_kes: kes, note });
  return j;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** Generates the paid deliverable for a paid order. Retries transient API failures. */
export async function deliver(db: DB, orderId: string) {
  const { data: order } = await db.from("orders").select("*").eq("id", orderId).single();
  if (!order || order.status !== "paid") return;
  const { data: svc } = await db.from("services").select("*").eq("id", order.service_id).single();
  let lastErr = "unknown error";
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const j = await claude(
        db,
        {
          model: MODEL,
          max_tokens: 2500,
          system: svc.system_prompt,
          messages: [{ role: "user", content: order.input }],
        },
        `deliver ${order.service_id}`,
        false,
      );
      const text = j.content.filter((b: { type: string }) => b.type === "text")
        // deno-lint-ignore no-explicit-any
        .map((b: any) => b.text).join("\n");
      if (!text.trim()) throw new Error("empty response");
      await db.from("orders").update({ status: "delivered", result: text, error: null }).eq("id", orderId);
      return;
    } catch (e) {
      lastErr = String((e as Error).message ?? e);
      if (attempt < 3) await sleep(Number(Deno.env.get("RETRY_DELAY_MS") ?? "2000") * attempt);
    }
  }
  // Customer paid but delivery failed: flag it so the owner can retry or refund.
  await db.from("orders").update({ error: lastErr }).eq("id", orderId);
}
