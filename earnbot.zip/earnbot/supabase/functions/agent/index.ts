import { admin, claude, cors, json, MODEL, monthTotals } from "../_shared/shared.ts";

const BUSINESS = Deno.env.get("BUSINESS_CONTEXT") ??
  "The owner runs a small pork butchery in Nakuru, Kenya, and sells paid AI services (CV rewrites, business plans) via M-Pesa.";

const SYSTEM = `You are Earnbot, an autonomous-but-supervised business agent. Goal: make the business a positive net income (earnings minus your own API costs). ${BUSINESS}

Hard rules:
- You never send messages, spend money or publish anything yourself. You only DRAFT into the approval queue; the owner approves.
- Never invent businesses, phone numbers or facts. Only add leads the owner named or described, or that you are asking them to verify. If you lack real contact details, say so.
- Be honest about uncertainty. Do not promise income. Check the ledger before proposing spend.
- Keep replies short, casual and practical. Prefer one concrete next step.
- WhatsApp outreach must be polite, specific, short, in English or Swahili as fits, and must not mislead.`;

const TOOLS = [
  {
    name: "get_ledger_summary",
    description: "Earnings, API costs and net for the current month, in KES.",
    input_schema: { type: "object", properties: {} },
  },
  {
    name: "list_leads",
    description: "List saved leads (latest 50).",
    input_schema: { type: "object", properties: {} },
  },
  {
    name: "add_lead",
    description: "Save a lead the owner mentioned. Do not invent contact details.",
    input_schema: {
      type: "object",
      properties: {
        name: { type: "string" },
        kind: { type: "string", description: "e.g. hotel, butchery, eatery, individual" },
        area: { type: "string" },
        contact: { type: "string", description: "phone/WhatsApp only if provided by the owner" },
        notes: { type: "string" },
      },
      required: ["name"],
    },
  },
  {
    name: "draft_outreach",
    description: "Draft a WhatsApp message to a lead. It goes to the approval queue, it is NOT sent.",
    input_schema: {
      type: "object",
      properties: { lead_id: { type: "string" }, message: { type: "string" } },
      required: ["lead_id", "message"],
    },
  },
  {
    name: "propose_service",
    description: "Propose a new paid service for the owner to approve.",
    input_schema: {
      type: "object",
      properties: {
        id: { type: "string", description: "short slug, lowercase" },
        name: { type: "string" },
        description: { type: "string" },
        price_kes: { type: "integer" },
        system_prompt: { type: "string", description: "instructions used to produce the deliverable" },
      },
      required: ["id", "name", "description", "price_kes", "system_prompt"],
    },
  },
  {
    name: "list_orders",
    description: "Latest 20 customer orders with status (phone numbers hidden).",
    input_schema: { type: "object", properties: {} },
  },
];

// deno-lint-ignore no-explicit-any
async function runTool(db: any, name: string, input: any) {
  switch (name) {
    case "get_ledger_summary":
      return await monthTotals(db);
    case "list_leads": {
      const { data } = await db.from("leads").select("*").order("created_at", { ascending: false })
        .limit(50);
      return data;
    }
    case "add_lead": {
      const { data, error } = await db.from("leads").insert({
        name: input.name,
        kind: input.kind,
        area: input.area,
        contact: input.contact,
        notes: input.notes,
      }).select().single();
      if (error) throw error;
      return data;
    }
    case "draft_outreach": {
      const { data: lead } = await db.from("leads").select("*").eq("id", input.lead_id).single();
      if (!lead) throw new Error("lead not found");
      const { error } = await db.from("actions").insert({
        type: "outreach",
        payload: { lead_id: lead.id, lead_name: lead.name, contact: lead.contact, message: input.message },
      });
      if (error) throw error;
      await db.from("leads").update({ status: "drafted" }).eq("id", lead.id);
      return { queued: true, note: "Waiting for owner approval." };
    }
    case "propose_service": {
      const { error } = await db.from("actions").insert({ type: "new_service", payload: input });
      if (error) throw error;
      return { queued: true, note: "Waiting for owner approval." };
    }
    case "list_orders": {
      const { data } = await db.from("orders")
        .select("id, created_at, service_id, amount_kes, status, error")
        .order("created_at", { ascending: false }).limit(20);
      return data;
    }
    default:
      throw new Error(`unknown tool ${name}`);
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "POST only" }, 405);

  const db = admin();
  const token = (req.headers.get("Authorization") ?? "").replace("Bearer ", "");
  const { data: auth } = await db.auth.getUser(token);
  const { data: s } = await db.from("settings").select("owner_email").eq("id", 1).single();
  const email = auth?.user?.email?.toLowerCase();
  if (!email || !s?.owner_email || email !== String(s.owner_email).toLowerCase()) {
    return json({ error: "forbidden" }, 403);
  }

  let history: { role: string; content: string }[];
  try {
    const body = await req.json();
    history = (body.messages ?? []).slice(-20).map((m: { role: string; content: string }) => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content).slice(0, 4000),
    }));
  } catch {
    return json({ error: "bad request" }, 400);
  }
  // Anthropic requires the conversation to start with a user turn; trimming to the last 20 can break that.
  while (history.length && history[0].role !== "user") history.shift();
  if (!history.length || history[history.length - 1].role !== "user") {
    return json({ error: "last message must be from user" }, 400);
  }

  try {
    // deno-lint-ignore no-explicit-any
    const msgs: any[] = [...history];
    for (let i = 0; i < 6; i++) {
      const res = await claude(
        db,
        { model: MODEL, max_tokens: 1500, system: SYSTEM, tools: TOOLS, messages: msgs },
        "agent chat",
      );
      msgs.push({ role: "assistant", content: res.content });
      if (res.stop_reason !== "tool_use") {
        const reply = res.content
          // deno-lint-ignore no-explicit-any
          .filter((b: any) => b.type === "text").map((b: any) => b.text).join("\n");
        return json({ reply });
      }
      // deno-lint-ignore no-explicit-any
      const results: any[] = [];
      for (const b of res.content) {
        if (b.type !== "tool_use") continue;
        let out;
        try {
          out = await runTool(db, b.name, b.input);
        } catch (e) {
          out = { error: String((e as Error).message ?? e) };
        }
        results.push({ type: "tool_result", tool_use_id: b.id, content: JSON.stringify(out ?? null) });
      }
      msgs.push({ role: "user", content: results });
    }
    return json({ reply: "I stopped after too many steps. Try a narrower request." });
  } catch (e) {
    return json({ error: String((e as Error).message ?? e) }, 500);
  }
});
