import { admin, deliver, json } from "../_shared/shared.ts";

// Safaricom posts the STK result here. The URL is protected by a shared secret, carries the order id
// (so we never depend on a race with the STK response), and the amount is verified.
Deno.serve(async (req) => {
  const url = new URL(req.url);
  if (url.searchParams.get("s") !== Deno.env.get("CALLBACK_SECRET")) {
    return json({ error: "forbidden" }, 403);
  }
  const db = admin();
  const body = await req.json().catch(() => null);
  const cb = body?.Body?.stkCallback;
  const ok = () => json({ ResultCode: 0, ResultDesc: "ok" });
  if (!cb?.CheckoutRequestID) return json({ ResultCode: 0, ResultDesc: "ignored" });

  const orderId = url.searchParams.get("o");
  const { data: order } = orderId
    ? await db.from("orders").select("*").eq("id", orderId).maybeSingle()
    : await db.from("orders").select("*").eq("checkout_request_id", cb.CheckoutRequestID).maybeSingle();
  if (!order) return ok();
  // A callback for a different checkout than the one we started for this order is not ours.
  if (order.checkout_request_id && order.checkout_request_id !== cb.CheckoutRequestID) return ok();

  if (cb.ResultCode !== 0) {
    await db.from("orders").update({ status: "failed", error: String(cb.ResultDesc ?? "payment failed") })
      .eq("id", order.id).eq("status", "pending_payment");
    return ok();
  }

  // deno-lint-ignore no-explicit-any
  const items: any[] = cb.CallbackMetadata?.Item ?? [];
  const get = (n: string) => items.find((i) => i.Name === n)?.Value;
  const amount = Number(get("Amount"));
  const receipt = String(get("MpesaReceiptNumber") ?? "");

  if (!(amount >= order.amount_kes)) {
    await db.from("orders").update({ status: "failed", error: `Underpaid: ${amount}` })
      .eq("id", order.id).eq("status", "pending_payment");
    return ok();
  }

  // Atomic claim: only ONE concurrent/retried callback can flip pending_payment -> paid.
  const { data: claimed } = await db.from("orders")
    .update({ status: "paid", mpesa_receipt: receipt })
    .eq("id", order.id).eq("status", "pending_payment").select();
  if (!claimed?.length) return ok();

  await db.from("ledger").insert({
    kind: "earning",
    amount_kes: amount,
    note: `order ${order.service_id}`,
    ref: receipt || order.id,
  });

  // Respond to Safaricom immediately, generate the deliverable in the background.
  // @ts-ignore EdgeRuntime is provided by Supabase Edge Functions
  EdgeRuntime.waitUntil(deliver(db, order.id));
  return ok();
});
