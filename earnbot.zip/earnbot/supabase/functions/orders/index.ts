import { admin, cors, json } from "../_shared/shared.ts";

const DARAJA = Deno.env.get("MPESA_ENV") === "production"
  ? "https://api.safaricom.co.ke"
  : "https://sandbox.safaricom.co.ke";

function normPhone(p: string) {
  const d = p.replace(/\D/g, "");
  if (/^0[17]\d{8}$/.test(d)) return "254" + d.slice(1);
  if (/^254[17]\d{8}$/.test(d)) return d;
  return null;
}

async function stkPush(phone: string, amount: number, callbackUrl: string) {
  const key = Deno.env.get("MPESA_CONSUMER_KEY")!;
  const secret = Deno.env.get("MPESA_CONSUMER_SECRET")!;
  const tokRes = await fetch(`${DARAJA}/oauth/v1/generate?grant_type=client_credentials`, {
    headers: { Authorization: "Basic " + btoa(`${key}:${secret}`) },
  });
  const tok = await tokRes.json();
  const short = Deno.env.get("MPESA_SHORTCODE")!;
  const pass = Deno.env.get("MPESA_PASSKEY")!;
  // Daraja expects Nairobi time (UTC+3), formatted YYYYMMDDHHMMSS.
  const ts = new Date(Date.now() + 3 * 3600_000).toISOString().replace(/[-:T.Z]/g, "").slice(0, 14);
  const res = await fetch(`${DARAJA}/mpesa/stkpush/v1/processrequest`, {
    method: "POST",
    headers: { Authorization: `Bearer ${tok.access_token}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      BusinessShortCode: short,
      Password: btoa(short + pass + ts),
      Timestamp: ts,
      TransactionType: Deno.env.get("MPESA_TXN_TYPE") ?? "CustomerPayBillOnline",
      Amount: amount,
      PartyA: phone,
      PartyB: Deno.env.get("MPESA_PARTYB") ?? short, // for a Till: shortcode = store number, PARTYB = till number
      PhoneNumber: phone,
      CallBackURL: callbackUrl,
      AccountReference: "EARNBOT",
      TransactionDesc: "Earnbot",
    }),
  });
  return await res.json();
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  const db = admin();
  const url = new URL(req.url);

  // Customer polls for status/result with the unguessable order id.
  if (req.method === "GET") {
    const id = url.searchParams.get("id");
    if (!id) {
      const { data } = await db.from("services").select("id, name, description, price_kes")
        .eq("active", true);
      return json({ services: data });
    }
    const { data } = await db.from("orders").select("status, result, error, service_id").eq("id", id)
      .maybeSingle();
    if (!data) return json({ error: "not found" }, 404);
    return json({
      status: data.status,
      result: data.result,
      // Paid but delivery failed: tell the customer honestly.
      problem: data.status === "paid" && data.error
        ? "Payment received but delivery hit a problem. We will fix or refund you."
        : null,
    });
  }

  if (req.method !== "POST") return json({ error: "method not allowed" }, 405);

  let body: { service_id?: string; phone?: string; input?: string };
  try {
    body = await req.json();
  } catch {
    return json({ error: "bad request" }, 400);
  }
  const phone = normPhone(body.phone ?? "");
  const input = String(body.input ?? "").trim();
  if (!phone) return json({ error: "Enter a valid Safaricom number, e.g. 07XXXXXXXX" }, 400);
  if (input.length < 20 || input.length > 6000) {
    return json({ error: "Please give a bit more detail (20 to 6000 characters)." }, 400);
  }

  const { data: svc } = await db.from("services").select("*").eq("id", body.service_id ?? "")
    .eq("active", true).maybeSingle();
  if (!svc) return json({ error: "Unknown service" }, 400);

  // Abuse guards: max 3 unpaid attempts per phone per hour, and a global ceiling so nobody can
  // use the app to spray M-Pesa prompts or fill the database.
  const since = new Date(Date.now() - 3600_000).toISOString();
  const { count: busy } = await db.from("orders").select("id", { count: "exact", head: true })
    .eq("status", "pending_payment").gte("created_at", since);
  if ((busy ?? 0) >= 60) return json({ error: "We're busy right now. Try again in a few minutes." }, 429);
  const { count } = await db.from("orders").select("id", { count: "exact", head: true })
    .eq("phone", phone).eq("status", "pending_payment").gte("created_at", since);
  if ((count ?? 0) >= 3) return json({ error: "Too many attempts. Try again in an hour." }, 429);

  const { data: order, error } = await db.from("orders").insert({
    service_id: svc.id,
    phone,
    input,
    amount_kes: svc.price_kes,
  }).select().single();
  if (error) return json({ error: "Could not create order" }, 500);

  const callback = `${Deno.env.get("SUPABASE_URL")}/functions/v1/mpesa-callback?s=${
    Deno.env.get("CALLBACK_SECRET")
  }&o=${order.id}`;
  try {
    const r = await stkPush(phone, svc.price_kes, callback);
    if (r.ResponseCode !== "0") throw new Error(r.errorMessage ?? r.ResponseDescription ?? "STK failed");
    await db.from("orders").update({ checkout_request_id: r.CheckoutRequestID }).eq("id", order.id);
    return json({ id: order.id, message: "Check your phone and enter your M-Pesa PIN." });
  } catch (e) {
    await db.from("orders").update({ status: "failed", error: String((e as Error).message ?? e) })
      .eq("id", order.id);
    return json({ error: "Could not start M-Pesa payment. Please try again." }, 502);
  }
});
