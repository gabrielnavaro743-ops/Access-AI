-- Earnbot schema. Run once (the deploy workflow does it, or paste into the Supabase SQL editor).

create table if not exists settings (
  id int primary key default 1 check (id = 1),
  owner_email text,
  monthly_cost_cap_usd numeric not null default 10
);
insert into settings (id) values (1) on conflict do nothing;

create table if not exists ledger (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  kind text not null check (kind in ('earning', 'cost')),
  amount_kes numeric not null,
  note text,
  ref text
);

create unique index if not exists ledger_earning_ref on ledger (ref) where kind = 'earning' and ref is not null;

create table if not exists leads (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text not null,
  kind text,
  area text,
  contact text,
  notes text,
  status text not null default 'new' check (status in ('new', 'drafted', 'sent', 'won', 'dead'))
);

-- Everything the agent wants to DO lands here first. Nothing leaves without the owner approving it.
create table if not exists actions (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  type text not null check (type in ('outreach', 'new_service')),
  payload jsonb not null,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  decided_at timestamptz
);

create table if not exists services (
  id text primary key,
  name text not null,
  description text,
  price_kes int not null check (price_kes >= 10),
  system_prompt text not null,
  active boolean not null default true
);

create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  service_id text not null references services (id),
  phone text not null,
  input text not null,
  amount_kes int not null,
  status text not null default 'pending_payment'
    check (status in ('pending_payment', 'paid', 'delivered', 'failed')),
  checkout_request_id text unique,
  mpesa_receipt text,
  result text,
  error text
);
create index if not exists orders_phone_created on orders (phone, created_at);

insert into services (id, name, description, price_kes, system_prompt) values
  ('cv', 'CV rewrite',
   'Paste your CV and the job you want. Get a sharper, ATS-friendly rewrite.',
   150,
   'You are an expert CV writer for the Kenyan job market. Rewrite the CV the customer pasted so it is concise, achievement-focused and honest. Never invent employers, dates, qualifications or numbers; if something is missing, leave a clear [ADD: ...] placeholder. Output plain text with clear section headings.'),
  ('bizplan', 'One-page business plan',
   'Describe your business idea. Get a practical one-page plan with costs and first steps.',
   300,
   'You are a practical small-business advisor in Kenya. From the customer''s description, write a one-page business plan: what you sell, who buys, simple startup costs in KES (state your assumptions), pricing, 30-day first steps, and top 3 risks. Be realistic, never promise profits. Plain text with headings.')
on conflict (id) do nothing;

-- Owner-only access from the app. Edge functions use the service role and bypass RLS.
create or replace function is_owner() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(lower(auth.jwt() ->> 'email') = lower((select owner_email from settings where id = 1)), false)
$$;

alter table settings enable row level security;
alter table ledger enable row level security;
alter table leads enable row level security;
alter table actions enable row level security;
alter table services enable row level security;
alter table orders enable row level security;

drop policy if exists owner_all_settings on settings;
create policy owner_all_settings on settings for all using (is_owner()) with check (is_owner());
drop policy if exists owner_read_ledger on ledger;
create policy owner_read_ledger on ledger for select using (is_owner());
drop policy if exists owner_all_leads on leads;
create policy owner_all_leads on leads for all using (is_owner()) with check (is_owner());
drop policy if exists owner_all_actions on actions;
create policy owner_all_actions on actions for all using (is_owner()) with check (is_owner());
drop policy if exists owner_all_services on services;
create policy owner_all_services on services for all using (is_owner()) with check (is_owner());
drop policy if exists owner_read_orders on orders;
create policy owner_read_orders on orders for select using (is_owner());
